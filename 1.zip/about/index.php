<?php
include('../sys/func.php');
start('О нас','about','о нас');
finish();
?>