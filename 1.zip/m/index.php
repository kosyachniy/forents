<?php
header('Content-type: text/html; charset=utf-8');
print '<div style="width: 100%; text-align: center; height: 49%; padding-top: 20%; font-size: 50px; font-family: \'Lato\', sans-serif;">Раздел в разработке</div>';
?>